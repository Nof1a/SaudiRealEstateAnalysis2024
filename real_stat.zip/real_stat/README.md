HTML & CSS REAL ESTATE WEB SITE 
https://mafspires.github.io/real_state_html/
